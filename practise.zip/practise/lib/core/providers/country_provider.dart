import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class CountryProvider extends ChangeNotifier {
  static const String _countryKey = 'selected_country';
  final SharedPreferences _prefs;
  String _selectedCountry;

  CountryProvider(this._prefs) : _selectedCountry = _prefs.getString(_countryKey) ?? 'us';

  String get selectedCountry => _selectedCountry;

  void setCountry(String countryCode) {
    _selectedCountry = countryCode;
    _prefs.setString(_countryKey, countryCode);
    notifyListeners();
  }

  static const Map<String, String> countries = {
    'us': 'United States',
    'gb': 'United Kingdom',
    'in': 'India',
    'au': 'Australia',
    'ca': 'Canada',
    'de': 'Germany',
    'fr': 'France',
    'jp': 'Japan',
  };
}