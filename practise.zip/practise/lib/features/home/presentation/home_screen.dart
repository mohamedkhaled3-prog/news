import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import '../../../core/providers/country_provider.dart';
import '../../../core/providers/network_provider.dart';
import '../../../core/theme/theme_provider.dart';
import '../bloc/news_bloc.dart';
import '../models/article.dart';
import 'widgets/article_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _scrollController = ScrollController();
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _loadInitialNews();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _loadInitialNews() {
    final country = context.read<CountryProvider>().selectedCountry;
    context.read<NewsBloc>().add(FetchTopHeadlines(country: country));
  }

  void _onScroll() async {
    if (!_isLoadingMore &&
        _scrollController.position.pixels >=
            _scrollController.position.maxScrollExtent - 200) {
      setState(() => _isLoadingMore = true);
      context.read<NewsBloc>().add(LoadMoreNews());
      // Wait for the state to update before allowing more loads
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) {
        setState(() => _isLoadingMore = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isOnline = context.watch<NetworkProvider>().isOnline;

    return Scaffold(
      appBar: AppBar(
        title: const Text('FlashNews'),
        actions: [
          IconButton(
            icon: Icon(
              context.watch<ThemeProvider>().isDarkMode
                  ? Icons.light_mode
                  : Icons.dark_mode,
            ),
            onPressed: () {
              context.read<ThemeProvider>().toggleTheme();
            },
          ),
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () => _showCountryPicker(context),
          ),
        ],
      ),
      body: Column(
        children: [
          if (!isOnline)
            Container(
              color: Colors.red,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: const Center(
                child: Text(
                  'You are offline. Showing cached news.',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          Expanded(
            child: BlocBuilder<NewsBloc, NewsState>(
              builder: (context, state) {
                if (state is NewsLoaded || state is NewsLoading || state is NewsError) {
                  final articles = (state is NewsLoaded)
                      ? state.articles
                      : (state is NewsLoading)
                          ? state.currentArticles ?? []
                          : (state as NewsError).currentArticles ?? [];

                  if (state is NewsLoading && articles.isEmpty) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (state is NewsError && articles.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(state.message),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadInitialNews,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    );
                  }

                  return RefreshIndicator(
                    onRefresh: () async {
                      final country = context.read<CountryProvider>().selectedCountry;
                      context.read<NewsBloc>().add(
                            FetchTopHeadlines(country: country, refresh: true),
                          );
                    },
                    child: ListView.builder(
                      controller: _scrollController,
                      itemCount: articles.length + (_isLoadingMore ? 1 : 0),
                      padding: const EdgeInsets.all(8),
                      itemBuilder: (context, index) {
                        if (index == articles.length) {
                          return const Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        return ArticleCard(article: articles[index]);
                      },
                    ),
                  );
                }

                // Initial state
                return const Center(child: CircularProgressIndicator());
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showCountryPicker(BuildContext context) {
    final countryProvider = context.read<CountryProvider>();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Country'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: CountryProvider.countries.entries.map((entry) {
              return ListTile(
                title: Text(entry.value),
                selected: countryProvider.selectedCountry == entry.key,
                onTap: () {
                  countryProvider.setCountry(entry.key);
                  _loadInitialNews();
                  Navigator.pop(context);
                },
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}