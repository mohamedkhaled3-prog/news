import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/api/news_api_service.dart';
import 'core/theme/theme_data.dart';
import 'core/theme/theme_provider.dart';
import 'core/providers/country_provider.dart';
import 'core/providers/network_provider.dart';
import 'core/routes/app_router.dart';
import 'features/home/bloc/news_bloc.dart';
import 'features/home/models/article.dart';
import 'widgets/navigation_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Hive
  await Hive.initFlutter();
  Hive.registerAdapter(ArticleAdapter());
  await Hive.openBox<Article>('favorites');
  
  // Initialize SharedPreferences
  final prefs = await SharedPreferences.getInstance();
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<ThemeProvider>(
          create: (_) => ThemeProvider(prefs),
        ),
        ChangeNotifierProvider<CountryProvider>(
          create: (_) => CountryProvider(prefs),
        ),
        ChangeNotifierProvider<NetworkProvider>(
          create: (_) => NetworkProvider(),
        ),
      ],
      child: Builder(
        builder: (context) => const FlashNewsApp(),
      ),
    ),
  );
}

class FlashNewsApp extends StatelessWidget {
  const FlashNewsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final countryProvider = context.watch<CountryProvider>();

    return ScreenUtilInit(
      designSize: const Size(375, 812),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => NewsBloc(
                newsApiService: NewsApiService(),
              )..add(FetchTopHeadlines(country: countryProvider.selectedCountry)),
            ),
          ],
          child: MaterialApp(
            title: 'FlashNews',
            theme: getLightTheme(),
            darkTheme: getDarkTheme(),
            themeMode: themeProvider.themeMode,
            debugShowCheckedModeBanner: false,
            onGenerateRoute: AppRouter.generateRoute,
            home: const NavigationScreen(),
          ),
        );
      },
    );
  }
}
