import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/article.dart';
import '../../../core/api/news_api_service.dart';

// Events
abstract class NewsEvent extends Equatable {
  const NewsEvent();

  @override
  List<Object> get props => [];
}

class FetchTopHeadlines extends NewsEvent {
  final String country;
  final bool refresh;

  const FetchTopHeadlines({
    required this.country,
    this.refresh = false,
  });

  @override
  List<Object> get props => [country, refresh];
}

class LoadMoreNews extends NewsEvent {}

class FetchCategoryNews extends NewsEvent {
  final String category;
  final String country;

  const FetchCategoryNews({
    required this.category,
    required this.country,
  });

  @override
  List<Object> get props => [category, country];
}

class SearchNews extends NewsEvent {
  final String query;

  const SearchNews(this.query);

  @override
  List<Object> get props => [query];
}

// States
abstract class NewsState extends Equatable {
  const NewsState();

  @override
  List<Object> get props => [];
}

class NewsInitial extends NewsState {}

class NewsLoading extends NewsState {
  final List<Article>? currentArticles;
  final bool isLoadingMore;

  const NewsLoading({
    this.currentArticles,
    this.isLoadingMore = false,
  });

  @override
  List<Object> get props => [currentArticles ?? [], isLoadingMore];
}

class NewsLoaded extends NewsState {
  final List<Article> articles;
  final bool hasReachedEnd;
  final int currentPage;

  const NewsLoaded({
    required this.articles,
    this.hasReachedEnd = false,
    this.currentPage = 1,
  });

  NewsLoaded copyWith({
    List<Article>? articles,
    bool? hasReachedEnd,
    int? currentPage,
  }) {
    return NewsLoaded(
      articles: articles ?? this.articles,
      hasReachedEnd: hasReachedEnd ?? this.hasReachedEnd,
      currentPage: currentPage ?? this.currentPage,
    );
  }

  @override
  List<Object> get props => [articles, hasReachedEnd, currentPage];
}

class NewsError extends NewsState {
  final String message;
  final List<Article>? currentArticles;

  const NewsError(this.message, {this.currentArticles});

  @override
  List<Object> get props => [message, currentArticles ?? []];
}

// BLoC
class NewsBloc extends Bloc<NewsEvent, NewsState> {
  final NewsApiService newsApiService;
  static const int _pageSize = 20;

  NewsBloc({required this.newsApiService}) : super(NewsInitial()) {
    on<FetchTopHeadlines>(_onFetchTopHeadlines);
    on<LoadMoreNews>(_onLoadMoreNews);
    on<FetchCategoryNews>(_onFetchCategoryNews);
    on<SearchNews>(_onSearchNews);
  }

  Future<void> _onFetchTopHeadlines(
    FetchTopHeadlines event,
    Emitter<NewsState> emit,
  ) async {
    if (event.refresh) {
      emit(NewsLoading());
    } else {
      final currentState = state;
      if (currentState is NewsLoaded) {
        emit(NewsLoading(currentArticles: currentState.articles));
      } else {
        emit(NewsLoading());
      }
    }

    try {
      final result = await newsApiService.getTopHeadlines(
        country: event.country,
        page: 1,
        pageSize: _pageSize,
      );
      
      final articles = (result['articles'] as List)
          .map((article) => Article.fromJson(article))
          .toList();
      
      final totalResults = result['totalResults'] as int;
      final hasReachedEnd = articles.length >= totalResults;

      emit(NewsLoaded(
        articles: articles,
        hasReachedEnd: hasReachedEnd,
        currentPage: 1,
      ));
    } catch (e) {
      final currentState = state;
      if (currentState is NewsLoading) {
        emit(NewsError(e.toString(), currentArticles: currentState.currentArticles));
      } else {
        emit(NewsError(e.toString()));
      }
    }
  }

  Future<void> _onLoadMoreNews(
    LoadMoreNews event,
    Emitter<NewsState> emit,
  ) async {
    final currentState = state;
    if (currentState is NewsLoaded && !currentState.hasReachedEnd) {
      try {
        final nextPage = currentState.currentPage + 1;
        final result = await newsApiService.getTopHeadlines(
          country: 'us', // Add default country or get it from state management
          page: nextPage,
          pageSize: _pageSize,
        );
        
        final newArticles = (result['articles'] as List)
            .map((article) => Article.fromJson(article))
            .toList();
        
        final totalResults = result['totalResults'] as int;
        final allArticles = [...currentState.articles, ...newArticles];
        final hasReachedEnd = allArticles.length >= totalResults;

        emit(NewsLoaded(
          articles: allArticles,
          hasReachedEnd: hasReachedEnd,
          currentPage: nextPage,
        ));
      } catch (e) {
        emit(NewsError(e.toString(), currentArticles: currentState.articles));
      }
    }
  }

  Future<void> _onFetchCategoryNews(
    FetchCategoryNews event,
    Emitter<NewsState> emit,
  ) async {
    emit(NewsLoading());
    try {
      final result = await newsApiService.getNewsByCategory(
        category: event.category,
        country: event.country,
      );
      final articles = (result['articles'] as List)
          .map((article) => Article.fromJson(article))
          .toList();
      emit(NewsLoaded(articles: articles));
    } catch (e) {
      emit(NewsError(e.toString()));
    }
  }

  Future<void> _onSearchNews(
    SearchNews event,
    Emitter<NewsState> emit,
  ) async {
    emit(NewsLoading());
    try {
      final result = await newsApiService.searchNews(
        query: event.query,
      );
      final articles = (result['articles'] as List)
          .map((article) => Article.fromJson(article))
          .toList();
      emit(NewsLoaded(articles: articles));
    } catch (e) {
      emit(NewsError(e.toString()));
    }
  }
}