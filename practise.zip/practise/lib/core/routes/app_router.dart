import 'package:flutter/material.dart';
import '../../features/article_details/presentation/article_details_screen.dart';
import '../../features/home/models/article.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/article-details':
        final article = settings.arguments as Article;
        return MaterialPageRoute(
          builder: (context) => ArticleDetailsScreen(article: article),
        );
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(
              child: Text('Route not found'),
            ),
          ),
        );
    }
  }
}