import 'package:hive/hive.dart';
import '../models/article.dart';

class ArticleAdapter extends TypeAdapter<Article> {
  @override
  final typeId = 0;

  @override
  Article read(BinaryReader reader) {
    return Article(
      title: reader.readString(),
      description: reader.readString(),
      url: reader.readString(),
      urlToImage: reader.readString(),
      publishedAt: reader.readString(),
      author: reader.readString(),
      content: reader.readString(),
    );
  }

  @override
  void write(BinaryWriter writer, Article obj) {
    writer.writeString(obj.title);
    writer.writeString(obj.description);
    writer.writeString(obj.url);
    writer.writeString(obj.urlToImage);
    writer.writeString(obj.publishedAt);
    writer.writeString(obj.author);
    writer.writeString(obj.content);
  }
}