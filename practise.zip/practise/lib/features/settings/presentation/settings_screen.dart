import 'package:flutter/material.dart';

import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late SharedPreferences _prefs;
  bool _isDarkMode = false;
  String _selectedCountry = 'us';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    _prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkMode = _prefs.getBool('darkMode') ?? false;
      _selectedCountry = _prefs.getString('country') ?? 'us';
      _isLoading = false;
    });
  }

  Future<void> _setDarkMode(bool value) async {
    await _prefs.setBool('darkMode', value);
    setState(() {
      _isDarkMode = value;
    });
  }

  Future<void> _setCountry(String value) async {
    await _prefs.setString('country', value);
    setState(() {
      _selectedCountry = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Dark Mode'),
            subtitle: const Text('Enable dark theme'),
            value: _isDarkMode,
            onChanged: _setDarkMode,
          ),
          const Divider(),
          ListTile(
            title: const Text('Country'),
            subtitle: const Text('Select your preferred news region'),
            trailing: DropdownButton<String>(
              value: _selectedCountry,
              onChanged: (String? value) {
                if (value != null) {
                  _setCountry(value);
                }
              },
              items: const [
                DropdownMenuItem(
                  value: 'us',
                  child: Text('United States'),
                ),
                DropdownMenuItem(
                  value: 'gb',
                  child: Text('United Kingdom'),
                ),
                DropdownMenuItem(
                  value: 'in',
                  child: Text('India'),
                ),
                DropdownMenuItem(
                  value: 'au',
                  child: Text('Australia'),
                ),
              ],
            ),
          ),
          const Divider(),
          AboutListTile(
            icon: const Icon(Icons.info),
            applicationName: 'FlashNews',
            applicationVersion: '1.0.0',
            applicationLegalese: '© 2025',
            aboutBoxChildren: const [
              SizedBox(height: 10),
              Text(
                'FlashNews is your one-stop destination for the latest news from around the world.',
              ),
            ],
          ),
        ],
      ),
    );
  }
}