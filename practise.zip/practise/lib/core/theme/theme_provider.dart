import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  static const String _themeKey = 'theme_mode';
  final SharedPreferences _prefs;
  late ThemeMode _themeMode;

  ThemeProvider(this._prefs) {
    // Initialize with saved theme or system default
    final savedThemeIndex = _prefs.getInt(_themeKey);
    if (savedThemeIndex != null) {
      _themeMode = ThemeMode.values[savedThemeIndex];
    } else {
      _themeMode = ThemeMode.system;
      _prefs.setInt(_themeKey, _themeMode.index);
    }
  }

  ThemeMode get themeMode => _themeMode;

  void setThemeMode(ThemeMode mode) {
    if (_themeMode == mode) return;
    _themeMode = mode;
    _prefs.setInt(_themeKey, mode.index);
    notifyListeners();
  }

  void toggleTheme() {
    final newMode = _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    setThemeMode(newMode);
  }

  bool get isDarkMode {
    if (_themeMode == ThemeMode.system) {
      // Check system theme
      final window = WidgetsBinding.instance.window;
      return window.platformBrightness == Brightness.dark;
    }
    return _themeMode == ThemeMode.dark;
  }
}