import 'dart:convert';
import 'package:http/http.dart' as http;

class NewsApiService {
  static const String _baseUrl = 'https://newsapi.org/v2';
  static const String _apiKey = '81b00b04c0d2452c9106f9a6220cfcfa';
  // Fetch top headlines
  Future<Map<String, dynamic>> getTopHeadlines({
    required String country,
    int page = 1,
    int pageSize = 20,
  }) async {
    try {
      final response = await http.get(
        Uri.parse(
          '$_baseUrl/top-headlines?country=$country&page=$page&pageSize=$pageSize&apiKey=$_apiKey',
        ),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        final error = json.decode(response.body);
        throw Exception(error['message'] ?? 'Failed to load top headlines');
      }
    } catch (e) {
      throw Exception('Error fetching top headlines: $e');
    }
  }

  // Fetch news by category
  Future<Map<String, dynamic>> getNewsByCategory({
    required String category,
    String country = 'us',
    int page = 1,
    int pageSize = 20,
  }) async {
    try {
      final response = await http.get(
        Uri.parse(
          '$_baseUrl/top-headlines?country=$country&category=$category&page=$page&pageSize=$pageSize&apiKey=$_apiKey',
        ),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load category news');
      }
    } catch (e) {
      throw Exception('Error fetching category news: $e');
    }
  }

  // Search news
  Future<Map<String, dynamic>> searchNews({
    required String query,
    int page = 1,
    int pageSize = 20,
  }) async {
    try {
      final response = await http.get(
        Uri.parse(
          '$_baseUrl/everything?q=$query&page=$page&pageSize=$pageSize&apiKey=$_apiKey',
        ),
      );

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to search news');
      }
    } catch (e) {
      throw Exception('Error searching news: $e');
    }
  }
}